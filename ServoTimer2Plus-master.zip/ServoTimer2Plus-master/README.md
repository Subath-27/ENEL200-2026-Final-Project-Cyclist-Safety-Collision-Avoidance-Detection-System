ServoTimer2Plus
===============

ServoTimer2Plus is a small Arduino servo library that uses Timer2 instead of Timer1.

It is based on the original ServoTimer2 library by Michael Margolis (2008), updated for Arduino 1.x by Nick Bontrager in 2013. This version keeps the same basic idea, but cleans up the API and implements explicit angle/pulse width behaviour.

Why?
---------------

The standard Arduino Servo library uses Timer1 on ATmega328P boards. Usually, that's fine, but sometimes, Timer1 is already needed for something else.

ServoTimer2Plus uses Timer2 instead, so you can use servos when Timer1 is occupied.

Main changes from ServoTimer2
-----------------------------

- Renamed to ServoTimer2Plus.
- `write(0..180)` writes an angle.
- `write(value > 180)` writes a pulse width in microseconds.
- `writeAngle(angle)` explicitly writes an angle.
- `writeMicroseconds(us)` explicitly writes a pulse width.
- `read()` returns the last written angle.
- `readMicroseconds()` returns the last written pulse width.
- `attach(pin, minPulse, maxPulse)` is implemented.
- `attach(pin, minPulse, maxPulse, minAngle, maxAngle)` is implemented.
- Channels are allocated on `attach()`, not in the constructor.
- `attach()` does not start pulsing the servo. The servo starts pulsing after the first write.
- Included default and strict limits on servos. Each servo can have its own soft limits.

Timer2 warning
--------------

This library reconfigures Timer2.

On ATmega328P boards like the Arduino Uno and Nano, Timer2 is also used for PWM on pins 3 and 11. That means normal `analogWrite()` PWM on pins 3 and 11 may be affected while this library is active.

Pins 3 and 11 can still be used as normal digital pins or as servo signal pins.

Basic use
---------

```cpp
#include <ServoTimer2Plus.h>

ServoTimer2Plus servo;

void setup() {
  servo.attach(9);

  servo.write(90);               // angle
  servo.writeMicroseconds(1500); // pulse width
}

void loop() {
}
```

Calibrated pulse range
----------------------

Different servos may not use the same pulse range. Something like an MG90s might be happy with 750-2250 us, but others can use something else.

```cpp
#include <ServoTimer2Plus.h>

ServoTimer2Plus servo;

void setup() {
  servo.attach(9, 900, 2650); //min pulse width = 900us, max pulse width = 2650 us

  servo.write(90); //now, a pulse is written using the new pulse limit values
}

void loop() {
}
```

Custom angle range
------------------

For servos that are not 0-180 degrees, use the full attach form and `writeAngle()`. No max angle exists.

```cpp
#include <ServoTimer2Plus.h>

ServoTimer2Plus servo;

void setup() {
  servo.attach(9, 500, 2500, 0, 270);

  servo.writeAngle(270); // full travel
}

void loop() {
}
```

**NOTE: Do not use `write(270)` for a 270 degree servo. In Arduino-style behavior, values over 180 are treated as microseconds. Use `writeAngle(270)`, instead!**

Return values
-------------

`attach()` returns the channel number on success.

It returns `0` if attachment fails.

Common reasons for failure:

- no free servo channels
- pulse range is invalid
- angle range is invalid
- the object is already attached

Build test
----------

This repo includes a small compile test.

```sh
make
```

Or directly:

```sh
arduino-cli compile --fqbn arduino:avr:uno --library . examples/CompileTest
```

License / credits
-----------------

Original ServoTimer2:

- Copyright (c) 2008 Michael Margolis
- Updated for Arduino 1.x by Nick Bontrager, 2013

ServoTimer2Plus modifications:

- Copyright (c) 2026 Victor Lelikov

This library is distributed under the GNU Lesser General Public License v2.1 or later.
