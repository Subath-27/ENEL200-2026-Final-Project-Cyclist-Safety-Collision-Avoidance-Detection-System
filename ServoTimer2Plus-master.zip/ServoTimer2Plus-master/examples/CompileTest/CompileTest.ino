#include <ServoTimer2Plus.h>

ServoTimer2Plus servo;

void setup() {
  servo.attach(9);

  servo.write(90);
  servo.writeAngle(180);
  servo.writeMicroseconds(1500);

  int angle = servo.read();
  int pulse = servo.readMicroseconds();

  (void)angle;
  (void)pulse;
}

void loop() {
}