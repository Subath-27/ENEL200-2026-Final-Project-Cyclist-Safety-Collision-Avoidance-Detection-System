/*
  ServoTimer2Plus basic angle range test

  This sketch uses sketch-level minAngle/maxAngle values.
  They only control what angles this example writes to the servo.
  They do not change the angle or pulse limits stored inside ServoTimer2Plus.
*/

#include <ServoTimer2Plus.h>

ServoTimer2Plus servo;

const int servoPin = A3;

// Change these two values to limit the sweep range used by this sketch.
// These are NOT library limits.
const int minAngle = 90;
const int maxAngle = 180;

const int stepSize = 1;
const int stepDelayMs = 15;

void setup()
{
  Serial.begin(9600);

  if (minAngle >= maxAngle) {
    Serial.println("Error: minAngle must be less than maxAngle.");
    while (true) {
      // Stop here so the servo does not do anything stupid.
    }
  }

  // Attach using the library defaults.
  // Do not pass minAngle/maxAngle here; these sketch constants are separate.
  if (servo.attach(servoPin) == 0) {
    Serial.println("Error: failed to attach servo.");
    while (true) {
      // No valid servo channel was available.
    }
  }

  servo.writeAngle(minAngle);
  delay(500);
}

void loop()
{
  for (int angle = minAngle; angle <= maxAngle; angle += stepSize) {
    servo.writeAngle(angle);
    delay(stepDelayMs);
  }

  delay(500);

  for (int angle = maxAngle; angle >= minAngle; angle -= stepSize) {
    servo.writeAngle(angle);
    delay(stepDelayMs);
  }

  delay(500);
}
