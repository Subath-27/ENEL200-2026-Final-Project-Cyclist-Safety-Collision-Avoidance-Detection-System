extern "C" {
  // AVR LibC Includes
  #include <inttypes.h>
  #include <avr/interrupt.h>
  // #include "WConstants.h"
}

#include <Arduino.h>
#include "ServoTimer2Plus.h"


static void initISR();   
static void writeChan(uint8_t chan, int pulsewidth);
static uint8_t findFreeChannel();

#define FRAME_SYNC_INDEX   0		 // frame sync delay is the first entry in the channel array
#define FRAME_SYNC_PERIOD  20000	   // total frame duration in microseconds 
#define FRAME_SYNC_DELAY   ((FRAME_SYNC_PERIOD - ( NBR_CHANNELS * DEFAULT_PULSE_WIDTH))/ 128) // number of iterations of the ISR to get the desired frame rate
#define DELAY_ADJUST	 8		 // number of microseconds of calculation overhead to be subtracted from pulse timings   

static servo_t servos[NBR_CHANNELS+1];    // static array holding servo data for all channels

static volatile uint8_t Channel;   // counter holding the channel being pulsed
static volatile uint8_t ISRCount;  // iteration counter used in the interrupt routines;
static boolean isStarted = false;  // flag to indicate if the ISR has been initialised

ISR (TIMER2_OVF_vect)
{ 
  ++ISRCount; // increment the overflow counter
  if (ISRCount ==  servos[Channel].counter ) // are we on the final iteration for this channel
  {
	TCNT2 =  servos[Channel].remainder;   // yes, set count for overflow after remainder ticks
  }  
  else if(ISRCount >  servos[Channel].counter)  
  {
	// we have finished timing the channel so pulse it low and move on
	if(servos[Channel].Pin.isActive == true)	     // check if activated
	    digitalWrite(servos[Channel].Pin.nbr,LOW);   // pulse this channel low if active   

	Channel++;    // increment to the next channel
	ISRCount = 0; // reset the isr iteration counter 
	TCNT2 = 0;    // reset the clock counter register

	if( (Channel != FRAME_SYNC_INDEX) && (Channel <= NBR_CHANNELS) ){	     // check if we need to pulse this channel    
	    if(servos[Channel].Pin.isActive == true)	   // check if activated
		 digitalWrite( servos[Channel].Pin.nbr,HIGH); // its an active channel so pulse it high   
	}
	else if(Channel > NBR_CHANNELS){ 
	   Channel = 0; // all done so start over		   
	} 
   }  
}

ServoTimer2Plus::ServoTimer2Plus()
{
	this->chanIndex = 0;	// Assign servo invalid channel until attached
}

/*
	ATTACH METHODS
*/

//Attempt to attach servo with default limit values. Return 0 on failure.
uint8_t ServoTimer2Plus::attach(int pin)
{
	return attach(pin, MIN_PULSE_WIDTH_DEFAULT, MAX_PULSE_WIDTH_DEFAULT, MIN_ANGLE_DEFAULT, MAX_ANGLE_DEFAULT);
}

//Attempt to attach servo with default limit angle values, custom pulse limit values, 
	//within hard limits. Return 0 on failure.
uint8_t ServoTimer2Plus::attach(int pin, int minPulse, int maxPulse)
{
	return attach(pin, minPulse, maxPulse, MIN_ANGLE_DEFAULT, MAX_ANGLE_DEFAULT);
}

//Attempt to attach servo with custom angle limit values, custom pulse limit values, 
	//within hard limits. Return 0 on failure
uint8_t ServoTimer2Plus::attach(int pin, int minPulse, int maxPulse, int minAngle, int maxAngle)
{
	if( isStarted == false)
		initISR();    

	// Hard constraints
	minPulse = constrain(minPulse, MIN_PULSE_WIDTH_LIMIT, MAX_PULSE_WIDTH_LIMIT);
	maxPulse = constrain(maxPulse, MIN_PULSE_WIDTH_LIMIT, MAX_PULSE_WIDTH_LIMIT);

	// Exit for invalid values
	if (minAngle >= maxAngle) return 0;
	if (minPulse >= maxPulse) return 0;

	// Attempt to attach servo
	if (this->chanIndex == 0) // not yet attached, doesn't own a channel yet.
	{
		this->chanIndex = findFreeChannel();
	}
	else return 0; // channel not = 0. already attached and/or owns a channel
	
	if(this->chanIndex > 0)  // found valid channel 
	{
		//debug("attaching chan = ", chanIndex);
		pinMode( pin, OUTPUT) ;  // set servo pin to output
		servos[this->chanIndex].Pin.nbr = pin;  
		servos[this->chanIndex].Pin.isAllocated = true;  
		servos[this->chanIndex].Pin.isActive = false;

		servos[this->chanIndex].minPulse = minPulse;
		servos[this->chanIndex].maxPulse = maxPulse;
		servos[this->chanIndex].minAngle = minAngle;
		servos[this->chanIndex].maxAngle = maxAngle;


		// default last values = 0
		servos[this->chanIndex].lastPulse = 0;
		servos[this->chanIndex].lastAngle = 0;
	} 
	else return 0; // no valid channel found

	return this->chanIndex ;
}

/*
	DETACH METHOD
*/

void ServoTimer2Plus::detach()  
{
	if (this->chanIndex == 0) return;

	uint8_t chan = this->chanIndex;
	digitalWrite(servos[chan].Pin.nbr, LOW);

    servos[this->chanIndex].Pin.isAllocated = false;
    servos[this->chanIndex].Pin.isActive = false;  
    servos[this->chanIndex].Pin.nbr = 0; 
	
	this->chanIndex = 0;
}

/*
	WRITE METHODS
*/

void ServoTimer2Plus::write(int value)
{	
	if (this->chanIndex == 0) return; // return for invalid servo
	servos[this->chanIndex].Pin.isActive = true; 

	// <=180 -> angle, EVEN for extended servos!
	int pulse_width;
	if (value <= 180) 
	{
		// constrain angle to valid servo limits 
		value = constrain(
			value,
			servos[this->chanIndex].minAngle, 
			servos[this->chanIndex].maxAngle
		);
		
		// map angle to pulse range and write using static function
		pulse_width = map(
			value, 
			servos[this->chanIndex].minAngle, 
			servos[this->chanIndex].maxAngle, 
			servos[this->chanIndex].minPulse, 
			servos[this->chanIndex].maxPulse
		);

		writeChan(this->chanIndex, pulse_width);
	}

	// >180 -> pulse width
	else
	{ 	
		pulse_width = constrain(
			value,
			servos[this->chanIndex].minPulse, 
			servos[this->chanIndex].maxPulse
		);

		writeChan(this->chanIndex, pulse_width); // call the static function to store the raw pulse width
	}

	// Write last pulse to current servo
	servos[this->chanIndex].lastPulse = pulse_width;

	// Write last angle to current servo
	// Map from pulse to angle
	int angle = map(
			pulse_width, 
			servos[this->chanIndex].minPulse, 
			servos[this->chanIndex].maxPulse,
			servos[this->chanIndex].minAngle, 
			servos[this->chanIndex].maxAngle
		);
	servos[this->chanIndex].lastAngle = angle;
}

void ServoTimer2Plus::writeAngle(int angle)
{	
	if (this->chanIndex == 0) return; // return for invalid servo
	servos[this->chanIndex].Pin.isActive = true; 

	angle = constrain(
		angle,
		servos[this->chanIndex].minAngle, 
		servos[this->chanIndex].maxAngle
	);
	
	// map angle to pulse range and write using static function
	int pulse_width = map(
		angle, 
		servos[this->chanIndex].minAngle, 
		servos[this->chanIndex].maxAngle, 
		servos[this->chanIndex].minPulse, 
		servos[this->chanIndex].maxPulse
	);

	writeChan(this->chanIndex, pulse_width);


	// Write last pulse to current servo
	servos[this->chanIndex].lastPulse = pulse_width;

	// Write last angle to current servo
	servos[this->chanIndex].lastAngle = angle;
}

void ServoTimer2Plus::writeMicroseconds(int pulse_width)
{	
	if (this->chanIndex == 0) return; // return for invalid servo
	servos[this->chanIndex].Pin.isActive = true; 

	pulse_width = constrain(
		pulse_width,
		servos[this->chanIndex].minPulse, 
		servos[this->chanIndex].maxPulse
	);

	writeChan(this->chanIndex, pulse_width);

	// Write last pulse to current servo
	servos[this->chanIndex].lastPulse = pulse_width;

	// Write last angle to current servo
	// Map from pulse to angle
	int angle = map(
			pulse_width, 
			servos[this->chanIndex].minPulse, 
			servos[this->chanIndex].maxPulse,
			servos[this->chanIndex].minAngle, 
			servos[this->chanIndex].maxAngle
		);
	servos[this->chanIndex].lastAngle = angle;
}

/*
	READ METHODS
*/

int ServoTimer2Plus::read()
{   
	if (this->chanIndex == 0) return 0; // return for invalid channel
	
	return servos[this->chanIndex].lastAngle; // else, return last angle written to servo
}

int ServoTimer2Plus::readMicroseconds()
{   
	if (this->chanIndex == 0) return 0; // return for invalid channel
	
	return servos[this->chanIndex].lastPulse; // else, return last pulse written to servo
}

 /*
	GETTER FOR ATTACHED METHOD
 */

boolean ServoTimer2Plus::attached()
{
    return this->chanIndex != 0 && servos[this->chanIndex].Pin.isActive ;
}

/*
	HELPERS
*/

// Write servo pulse width to specific channel
static void writeChan(uint8_t chan, int pulsewidth)
{
   // calculate and store the values for the given channel
   if( (chan > 0) && (chan <= NBR_CHANNELS) )   // ensure channel is valid
   { 
	if( pulsewidth < MIN_PULSE_WIDTH_LIMIT )		    // ensure pulse width is valid
	    pulsewidth = MIN_PULSE_WIDTH_LIMIT;
	else if( pulsewidth > MAX_PULSE_WIDTH_LIMIT )
	    pulsewidth = MAX_PULSE_WIDTH_LIMIT;	 
	
	pulsewidth -=DELAY_ADJUST;			 // subtract the time it takes to process the start and end pulses (mostly from digitalWrite) 
	
	servos[chan].counter = pulsewidth / 128; // prescale OVF time	
	servos[chan].remainder = 255 - (2 * (pulsewidth - ( servos[chan].counter * 128)));  // the number of 0.5us ticks for timer overflow	   
   }
}

// initialise interrupt subroutine
static void initISR()
{   
	for(uint8_t i=1; i <= NBR_CHANNELS; i++) {  // channels start from 1    
	   writeChan(i, DEFAULT_PULSE_WIDTH);  // store default values	    
	}

	servos[FRAME_SYNC_INDEX].counter = FRAME_SYNC_DELAY;   // store the frame sync period	 

	Channel = 0;  // clear the channel index  
	ISRCount = 0;  // clear the value of the ISR counter;
	
	/* setup for timer 2 */
	TIMSK2 = 0;  // disable interrupts 
	TCCR2A = 0;  // normal counting mode 
	TCCR2B = _BV(CS21); // set prescaler of 8 
	TCNT2 = 0;     // clear the timer2 count 
	TIFR2 = _BV(TOV2);  // clear pending interrupts; 
	TIMSK2 =  _BV(TOIE2) ; // enable the overflow interrupt	  
	  
	isStarted = true;  // flag to indicate this initialisation code has been executed
} 

// Find free servo channel. Return 0 if not found
static uint8_t findFreeChannel()
{
	for (uint8_t i = 1; i <= NBR_CHANNELS; i++){
		if (!servos[i].Pin.isAllocated){
			return i;
		}
	}

	return 0;
}