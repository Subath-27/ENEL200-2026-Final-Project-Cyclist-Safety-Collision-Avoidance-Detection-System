/*
  ServoTimer2Plus.h - interrupt driven servo library for Arduino using Timer2

  Based on ServoTimer2:
    Copyright (c) 2008 Michael Margolis.
    Updated for Arduino 1.x by Nick Bontrager, 2013.

  ServoTimer2Plus modifications:
    Copyright (c) 2026 Victor Lelikov.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details.
  
  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <https://www.gnu.org/licenses/>.
*/

/*
  ServoTimer2Plus uses Timer2 to drive up to 8 servos from an interrupt.

  It is meant for cases where the normal Arduino Servo library is not ideal
  because Timer1 is already being used elsewhere.

  Basic behavior:

    attach(pin)
      Attach to a pin using the default pulse and angle range.

    attach(pin, minPulse, maxPulse)
      Attach with a custom pulse range in microseconds.

    attach(pin, minPulse, maxPulse, minAngle, maxAngle)
      Attach with a custom pulse range and custom angle range.

    write(value)
      Arduino-style write.
      0 through 180 are treated as angles.
      Values over 180 are treated as pulse widths in microseconds.

    writeAngle(angle)
      Explicit angle write. Use this for servos with ranges beyond 180 degrees.

    writeMicroseconds(us)
      Explicit pulse width write.

    read()
      Returns the last written angle.

    readMicroseconds()
      Returns the last written pulse width.

    attached()
      Returns true if this object has an allocated servo channel.

    detach()
      Stops pulsing the servo and frees the channel.

  attach() does not start pulsing the servo. The servo starts pulsing after the
  first write(), writeAngle(), or writeMicroseconds() call.

  Timer2 note:

    On ATmega328P boards like the Arduino Uno and Nano, Timer2 is also used for
    analogWrite() PWM on pins 3 and 11. Because this library reconfigures
    Timer2, PWM on pins 3 and 11 may be affected while the library is active.
*/

// ensure this library description is only included once
#ifndef ServoTimer2Plus_h
#define ServoTimer2Plus_h

#include <inttypes.h>
//typedef uint8_t boolean;
//typedef uint8_t byte;

#define MIN_PULSE_WIDTH_DEFAULT       750        // the shortest pulse sent to a servo (default)
#define MAX_PULSE_WIDTH_DEFAULT      2250        // the longest pulse sent to a servo (default) 
#define MIN_PULSE_WIDTH_LIMIT       750        // the shortest pulse sent to a servo (hard limit)
#define MAX_PULSE_WIDTH_LIMIT      2250        // the longest pulse sent to a servo (hard limit) 

#define MIN_ANGLE_DEFAULT             0          // the minimum default servo angle (default)
#define MAX_ANGLE_DEFAULT             180        // the maximum default servo angle (default)

#define DEFAULT_PULSE_WIDTH  1500        // default pulse width when servo is attached

#define FRAME_SYNC_PERIOD   20000        // total frame duration in microseconds 

#define NBR_CHANNELS 8                   // the maximum number of channels, don't change this 

typedef struct  {

      uint8_t nbr        :5 ;  // a pin number from 0 to 31

      uint8_t isActive      :1 ;  // false if this channel not being written to, pin only pulsed if true 
      uint8_t isAllocated   :1 ;  // false if this channel not allocated


   } ServoPin_t   ;  



typedef struct {

  ServoPin_t Pin;

  byte counter;
  byte remainder;

  int minPulse;
  int maxPulse;
  int minAngle;
  int maxAngle;

  int lastAngle;
  int lastPulse;

}  servo_t;

class ServoTimer2Plus
{
  public:
    // constructor:
    ServoTimer2Plus();

    uint8_t attach(int pin);     // attach the given pin to the next free channel, set pinMode, return channel number or 0 if failure
                                // the attached servo is pulsed with the current pulse width value (see the write method) 
    uint8_t attach(int pin, int minPulse, int maxPulse); // as above but also set min and max values for writes.
    uint8_t attach(int pin, int minPulse, int maxPulse, int minAngle, int maxAngle); // as above, but set associated max/min angles for non 0-180 servos

    void detach();
    
    void write(int value);    // store the pulse width or angle in microseconds (between MIN_PULSE_WIDTH and MAX_PULSE_WIDTH) for this channel
                              // 0 to 180 -> angle; greater than 180 -> microseconds
    void writeAngle(int angle);     // explicit angle
    void writeMicroseconds(int us); // explicit microseconds

    int read(); 			 // returns last written angle for this servo
    int readMicroseconds(); // as above but for pulse width
    
    boolean attached();      // return true if this servo is attached 

  private:
	  uint8_t chanIndex;      // index into the channel data for this servo
};

#endif
